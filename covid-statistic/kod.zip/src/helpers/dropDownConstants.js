export const options = [
  { value: "croCases", label: "Hrvatska zaraženi" },
  { value: "croDeaths", label: "Hrvatska umrli" },
  { value: "croCured", label: "Hrvatska izliječeni" },
  { value: "worldCases", label: "Svijet zaraženi" },
  { value: "worldDeaths", label: "Svijet umrli" },
  { value: "worldCured", label: "Svijet izliječeni" },
];
