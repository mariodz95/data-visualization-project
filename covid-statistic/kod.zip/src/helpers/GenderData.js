export default class GenderData {
  constructor(male, female) {
    this.male = male;
    this.female = female;
  }
}
