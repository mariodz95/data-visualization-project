export default class PieData {
  constructor(young, youngMedium, oldMedium, old) {
    this.young = young;
    this.youngMedium = youngMedium;
    this.oldMedium = oldMedium;
    this.old = old;
  }
}
