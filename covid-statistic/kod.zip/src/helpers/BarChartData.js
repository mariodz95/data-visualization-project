export default class BarChartData {
  constructor(value, state) {
    this.value = value;
    this.state = state;
  }
}
